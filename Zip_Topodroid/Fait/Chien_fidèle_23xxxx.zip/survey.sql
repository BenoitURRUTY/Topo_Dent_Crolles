INSERT into surveys values( 32, "Chien_fidèle_23xxxx", "2023.08.16", "Alain", 2.7000, "Point gps voir photo", "Cf0", 0, 0, 0 );
INSERT into fixeds values( 32, 1, "Cf0", 5.860874, 45.320450, 1829.80, 1779.31 "", 0, 2, "", 0.000000, 0.000000, 0.0, 2, 2, 0.0000, -1.0, -1.0, 1.000000 );
