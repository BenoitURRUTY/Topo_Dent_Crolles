INSERT into surveys values( 27, "P40_23xxxx", "2023.08.16", "Alain", 2.7000, "point gps sur broche de droite", "Pq0", 0, 0, 0 );
INSERT into fixeds values( 27, 1, "Pq0", 5.853513, 45.312488, 1989.95, 1939.43 "", 0, 2, "", 0.000000, 0.000000, 0.0, 2, 2, 0.0000, -1.0, -1.0, 1.000000 );
