INSERT into surveys values( 31, "A4_23xxxx", "2023.08.16", "Alain", 2.7000, "point gps sur spit du haut", "Aq0", 0, 0, 0 );
INSERT into fixeds values( 31, 1, "Aq0", 5.864512, 45.319833, 1913.51, 1863.00 "", 0, 2, "", 0.000000, 0.000000, 0.0, 2, 2, 0.0000, -1.0, -1.0, 1.000000 );
